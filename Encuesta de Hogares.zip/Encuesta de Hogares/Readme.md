# Encuesta Hogares CABA 2026-2019

## Descripción

Análisis de datos sobre la encuesta de hogares realizada por la ciudad de Buenos Aires durante el período 2016 - 2019

## Autor

Cecilia Caimi

## Contenido

- Carpeta principal con archivo de consigna y subcarpetas: data y notebooks
- Subcarpeta data con subcarpetas y 4 archivos .csv como dataset dentro de la subcarpeta raw
- Subcarpeta notebooks con 3 archivos.ipynb

## Instrucciones de ejecución

1. Descargar el archivo zip a una carpeta local
2. Descomprimir el archivo
3. Utilizar Jupyterlab para abrir las notebooks
4. Ejecutar las notebooks en el siguiente orden:
   - 01_data_processing.ipynb
   - 02_data_discovery.ipynb
   - 03_EDA.ipynb